package com.evoltride.backend.controller;

import com.evoltride.backend.dto.RideRequest;
import com.evoltride.backend.service.RideService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rides")
public class RideController {

    private final RideService rideService;

    public RideController(RideService rideService) {
        this.rideService = rideService;
    }

    @PostMapping("/book")
    public String bookRide(@RequestBody RideRequest request) {
        return rideService.bookRide(request);
    }
}